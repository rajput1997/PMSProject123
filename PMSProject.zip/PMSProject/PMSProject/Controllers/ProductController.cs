﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using PMSProject.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PMSProject.Controllers
{
    public class ProductController : Controller
    {
        private PMSDBContext dbContext;
        public IHostingEnvironment Environment { get; }

        public ProductController(PMSDBContext context, IHostingEnvironment environment)
        {
            dbContext = context;
            Environment = environment;
        }


        public IActionResult Index()
        {
            var pro = dbContext.Employees.ToList();
            return View(pro);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Product product)
        {

            var files = Request.Form.Files;
            string dbPath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbPath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }

            product.Image = dbPath;
            dbContext.Products.Add(product);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }

        public IActionResult Details()
        {
            return View();
        }
    }
}

    



